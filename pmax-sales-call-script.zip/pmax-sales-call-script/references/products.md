# Dữ liệu 9 Product — Pain Fit / DM / 3 USP / ROI / DISC

Mỗi mục dưới đây là nguồn dữ liệu chuẩn cho 1 product. Khi viết script, lấy đúng Pain Fit, 3 USP, ROI Angle từ đây — không tự thêm số liệu ngoài những gì được liệt kê.

---

## 1. Influencer (KOL/KOC/Brand Ambassador)

**Pain Fit:** Awareness thấp, cần social proof nhanh, ra mắt sản phẩm mới cần seeding, muốn viral nhưng ngại rủi ro chọn sai KOL.

**DM thường gặp:**
- Brand Manager / Marketing Manager — KPI reach, engagement, brand lift
- Founder/CEO (SME) — muốn kết quả nhanh, ngại chi tiền mà không đo được hiệu quả
- CMO (Enterprise) — cần influencer nằm trong chiến lược tổng thể, không muốn chạy rời rạc

**3 USP:**
1. Mạng lưới KOL/KOC đa tier (Celeb Tier 1 đến Community seeding) — chọn đúng người, đúng ngân sách.
2. Quy trình booking có kiểm soát chất lượng nội dung, đúng thông điệp thương hiệu, giảm rủi ro scandal.
3. Đo lường hiệu quả gắn với business goal, không chỉ đếm view mà đo brand lift/lead thực tế.

**ROI Angle:** Dealsize theo tier khoảng 50M (Community seeding) đến 600M–1B (Tier 1/Brand Ambassador). Nói theo cost-per-qualified-engagement so với chi phí và rủi ro nếu team tự research, tự chọn KOL.

**DISC mẫu:**
- D: "Anh/chị cần kết quả nhanh và đo được. PMAX có sẵn network KOL đã qua sàng lọc, book được trong 3–5 ngày, và cam kết KPI reach/engagement rõ ràng trước khi ký."
- I: "Em thấy campaign gần đây bên mình rất thú vị! Nếu kết hợp thêm KOL đúng gu, câu chuyện thương hiệu sẽ lan tỏa mạnh hơn — mình trao đổi nhanh ý tưởng được không ạ?"
- S: "Em hiểu chọn KOL rủi ro vì sợ sai người hoặc scandal. PMAX có quy trình kiểm soát nội dung và hợp đồng rõ ràng, giảm rủi ro cho team mình rất nhiều."
- C: "Bên em có dữ liệu hiệu quả theo từng tier KOL, từ reach, engagement rate đến chi phí trên mỗi tương tác — em gửi báo cáo benchmark ngành để anh/chị đối chiếu trước khi quyết định."

---

## 2. Creative

**Pain Fit:** Thiếu ý tưởng sáng tạo, chiến dịch launch cần concept mạnh, cần production (TVC/KV/Video) chuyên nghiệp.

**DM thường gặp:**
- Brand Manager — KPI chất lượng & tiến độ output creative
- Marketing Director / CMO — KPI hiệu quả tổng thể chiến dịch, tính nhất quán thông điệp

**3 USP:**
1. Đội ngũ concept có kinh nghiệm IMC — không chỉ làm đẹp mà gắn với chiến lược kinh doanh.
2. Production đa dạng: video, AI production, social content — linh hoạt theo ngân sách.
3. Có thể đi kèm hoặc độc lập với Media, giúp thông điệp nhất quán từ ý tưởng đến thực thi.

**ROI Angle:** Dealsize từ khoảng 30M (mini concept) đến 700M (IMC concept partner). Nói theo chi phí cơ hội của một chiến dịch launch thất bại vì concept yếu, so với chi phí đầu tư một concept mạnh ngay từ đầu.

**DISC mẫu:**
- D: "Concept mạnh giúp campaign launch nhanh và tạo impact ngay — tụi em có thể trình concept đầu tiên trong 1 tuần."
- I: "Ý tưởng sáng tạo là thứ giúp thương hiệu được nhớ tới — team Creative PMAX rất thích thử những concept táo bạo, phù hợp câu chuyện bên mình."
- S: "Tụi em làm việc theo quy trình rõ ràng: concept → feedback → chỉnh sửa → final, để anh/chị luôn kiểm soát được tiến độ, không bị bất ngờ."
- C: "PMAX có case study cho từng loại hình creative, kèm số liệu hiệu quả (engagement, view-through rate) để anh/chị tham khảo trước khi chọn hướng."

---

## 3. Strategy

**Pain Fit:** Marketing rời rạc, chưa có định vị rõ, cần chiến lược tổng thể trước khi triển khai chiến dịch, hoặc brand mới ra mắt/mở rộng thị trường.

**DM thường gặp:**
- CMO / VP Marketing — KPI định hướng chiến lược dài hạn
- Founder/COO (đang mở rộng) — cần go-to-market strategy rõ ràng trước khi đầu tư

**3 USP:**
1. Đánh giá toàn diện (brand health check, market entry research) trước khi đề xuất giải pháp.
2. Kết nối chiến lược với thực thi: Strategy → Creative → Media → Influencer trong một hệ sinh thái.
3. Đội chuyên trách theo từng mảng: Brand strategy, GTM, Pricing, Marketing operation design.

**ROI Angle:** Dealsize Strategy Consulting khoảng 50M–200M+. Nói theo chi phí cơ hội nếu triển khai sai chiến lược — chạy quảng cáo khi chưa định vị rõ thường đốt ngân sách nhiều hơn nhiều lần chi phí tư vấn.

**DISC mẫu:**
- D: "Trước khi rót ngân sách vào quảng cáo, mình cần một chiến lược rõ ràng để tránh đốt tiền sai hướng — PMAX có thể làm song song, không làm chậm tiến độ campaign."
- I: "Em rất tò mò về định hướng thương hiệu bên mình sắp tới — một buổi trao đổi chiến lược chắc chắn sẽ mở ra nhiều góc nhìn thú vị."
- S: "Team Strategy sẽ đi từng bước: audit hiện trạng, họp thống nhất định hướng, rồi mới đề xuất kế hoạch, để anh/chị luôn nắm rõ từng giai đoạn."
- C: "Tụi em có framework đánh giá gồm brand health check, market entry research và marketing operation design — em có thể gửi cách đo brand health trước để anh/chị tham khảo."

---

## 4. ScanMax

> **LƯU Ý QUAN TRỌNG — CHƯA XÁC NHẬN:** thông tin sản phẩm ScanMax không có trong tài liệu tham khảo gốc (Sales Call Playbook và bảng dữ liệu sản phẩm/deal PMAX). Nội dung dưới đây chỉ là khung giả định dựa trên logic chung của một sản phẩm audit/scan nhẹ. **Luôn nói rõ với BD rằng cần xác nhận lại với team Product trước khi dùng với khách hàng thật** — không trình bày phần này như dữ liệu đã xác nhận.

**Pain Fit (giả định):** công cụ chấm điểm/scan nhanh hiệu quả marketing hiện tại — dùng làm bước mở đầu (door-opener) trước khi đề xuất giải pháp lớn hơn.

**DM thường gặp (giả định):**
- Marketing Executive/Specialist — người vận hành hàng ngày, cần biết nhanh điểm nghẽn
- Brand Manager — cần cơ sở dữ liệu để đề xuất ngân sách/giải pháp mới

**3 USP (giả định):**
1. Chấm điểm nhanh hiệu quả marketing hiện tại, không cần cam kết hợp đồng dài hạn.
2. Chỉ ra điểm nghẽn cụ thể (kênh, creative, targeting) làm cơ sở đề xuất giải pháp đúng.
3. Chi phí thấp, dễ được duyệt nội bộ — phù hợp làm bước đầu xây dựng lòng tin với khách mới.

**ROI Angle (giả định):** Định vị như một audit nhẹ, chi phí thấp; ROI là tiết kiệm thời gian ra quyết định.

**DISC mẫu (giả định):**
- D: "Chỉ cần 15 phút, ScanMax sẽ chỉ ra ngay điểm marketing đang lãng phí ngân sách nhiều nhất."
- I: "ScanMax giống như một buổi khám sức khỏe nhanh cho marketing — nhẹ nhàng nhưng rất đáng để thử."
- S: "Không cần cam kết gì cả, mình có thể bắt đầu bằng một lần scan thử để xem có phù hợp không."
- C: "ScanMax chấm điểm theo bộ tiêu chí cụ thể, có báo cáo chi tiết để anh/chị đối chiếu với hiện trạng."

---

## 5. Audit Vista

**Pain Fit:** Doanh nghiệp lớn cần kiểm soát compliance thương hiệu trên nhiều kênh/nhiều agency, lo ngại rủi ro sai lệch hình ảnh thương hiệu.

**DM thường gặp:**
- CMO / Brand Director — chịu trách nhiệm về tính nhất quán thương hiệu
- COO (Enterprise) — quan tâm rủi ro vận hành và pháp lý liên quan thương hiệu

**3 USP:**
1. Giải pháp Lock-in/Moat — kiểm soát compliance thương hiệu tự động trên diện rộng, nhiều kênh, nhiều đối tác.
2. Dealsize lớn (khoảng 600M–15B), phù hợp doanh nghiệp có ngân sách marketing lớn, nhiều bên liên quan.
3. Giảm rủi ro hình ảnh thương hiệu/pháp lý do sai sót từ agency hoặc đối tác thứ ba.

**ROI Angle:** Nói theo chi phí rủi ro: một khủng hoảng truyền thông do sai lệch thương hiệu thường tốn kém hơn nhiều lần chi phí đầu tư Audit Vista.

**DISC mẫu:**
- D: "Nếu một sai sót thương hiệu xảy ra trên diện rộng, chi phí xử lý khủng hoảng có thể gấp nhiều lần ngân sách Audit Vista. Tụi em demo nhanh cách hệ thống phát hiện sai lệch trong 15 phút."
- I: "Đây là công cụ giúp CMO yên tâm hơn vì luôn biết thương hiệu đang được thể hiện đúng trên mọi kênh."
- S: "Audit Vista triển khai theo từng giai đoạn, không xáo trộn vận hành hiện tại, có báo cáo định kỳ để anh/chị theo dõi."
- C: "Tụi em có thể chia sẻ cách hệ thống chấm điểm compliance, tần suất quét, và case thực tế đã phát hiện sai lệch ở khách hàng cùng ngành."

---

## 6. Media

**Pain Fit:** Cần chạy quảng cáo hiệu quả (branding hoặc leadgen), CPL tăng, hoặc cần scale ngân sách lớn với chi phí minh bạch.

**DM thường gặp:**
- Marketing Executive / Digital Marketing Manager — KPI hiệu suất chạy ads hàng ngày
- CMO — KPI tổng ngân sách và hiệu quả toàn kênh

**3 USP:**
1. Danh mục linh hoạt: Selfserve, Booking, Transparent cost hoặc Unit cost — phù hợp mọi quy mô ngân sách.
2. Kinh nghiệm đa ngành (FMCG, Real Estate, Finance, Health Care...) với benchmark riêng từng ngành.
3. Tích hợp được với Creative, Data (CFP/MMM) để tối ưu hiệu quả toàn phễu, không chỉ tối ưu quảng cáo đơn lẻ.

**ROI Angle:** Nói theo % giảm CPL/CPA so với benchmark ngành, hoặc mức độ minh bạch chi phí giúp tối ưu ngân sách hiệu quả hơn.

**DISC mẫu:**
- D: "Nếu CPL đang tăng, tụi em có thể audit nhanh tài khoản hiện tại và chỉ ra ngay điểm đang lãng phí ngân sách."
- I: "Mỗi ngành hàng có một công thức chạy quảng cáo riêng, và tụi em rất thích tìm ra công thức phù hợp nhất cho từng brand."
- S: "Tụi em minh bạch từng đồng chi tiêu, có báo cáo định kỳ rõ ràng để team luôn nắm được ngân sách đang đi đâu."
- C: "Em có thể gửi benchmark CPL/CPA theo ngành của bên mình để anh/chị đối chiếu với hiệu suất hiện tại trước khi quyết định."

---

## 7. Leadgen

**Pain Fit:** Thiếu lead, lead kém chất lượng, hoặc cần tối ưu toàn phễu từ targeting đến conversion.

**DM thường gặp:**
- Sales Manager / BD Manager — KPI số lượng & chất lượng lead cho Sales
- Marketing Manager / CMO — KPI hiệu quả chi phí trên mỗi lead hợp lệ

**3 USP:**
1. Tối ưu toàn phễu (Targeting → Creative → Landing page → Conversion), không chỉ chạy ads đơn lẻ.
2. Có Sale Analysis & Planning đi kèm — phân tích chất lượng lead trước khi scale ngân sách.
3. Kinh nghiệm sâu ở ngành có funnel phức tạp (Finance, Education) với unit cost minh bạch.

**ROI Angle:** Nói theo mức giảm Cost per Qualified Lead, hoặc số lead/tháng cần thiết để Sales đạt target doanh số — PMAX giúp đạt volume ổn định hơn.

**DISC mẫu:**
- D: "Nếu Sales đang thiếu lead để đạt target tháng này, tụi em có thể review funnel và đề xuất hướng tăng volume trong 1 tuần."
- I: "Leadgen hiệu quả không chỉ là chạy ads, mà là kể đúng câu chuyện để khách chủ động để lại thông tin — đó là phần tụi em rất thích làm."
- S: "Tụi em sẽ cùng Sales team review chất lượng lead định kỳ, điều chỉnh dần để không xáo trộn quy trình hiện tại."
- C: "Em có thể chia sẻ số liệu cost-per-qualified-lead theo ngành để anh/chị so sánh với chi phí hiện tại."

---

## 8. Branding

**Pain Fit:** Awareness thấp, cần định vị lại thương hiệu, hoặc cần chiến dịch IMC tổng thể (Launch, Reposition, Brandformance).

**DM thường gặp:**
- CMO / Marketing Director — KPI awareness, brand health, tính nhất quán thông điệp
- Brand Manager — KPI chất lượng thực thi từng chiến dịch

**3 USP:**
1. Giải pháp IMC trọn gói: Strategy + Creative + Media + KOL + PR + Event, đồng bộ một thông điệp.
2. Nhiều gói theo ngân sách (Lite đến Premium), linh hoạt scale theo giai đoạn phát triển thương hiệu.
3. Case study đa ngành, đặc biệt mạnh ở FMCG, Health Care, Real Estate.

**ROI Angle:** Nói theo mức tăng brand lift/awareness, hoặc so với chi phí thuê nhiều agency lẻ cho từng hạng mục — PMAX gộp lại giúp tiết kiệm chi phí quản lý và đảm bảo nhất quán thông điệp.

**DISC mẫu:**
- D: "Nếu đang cần ra mắt hoặc tái định vị thương hiệu, tụi em có gói IMC trọn gói để tránh mất thời gian làm việc với nhiều agency lẻ."
- I: "Một chiến dịch IMC tốt là khi mọi kênh đều kể chung một câu chuyện — đó là điều tụi em muốn giúp bên mình đạt được."
- S: "Gói Branding có nhiều mức từ Lite đến Premium, tụi em sẽ đề xuất mức phù hợp với ngân sách và giai đoạn hiện tại, không ép scale quá nhanh."
- C: "Em có thể gửi case study IMC cùng ngành để anh/chị tham khảo kết quả brand lift thực tế trước khi quyết định."

---

## 9. MMM (Marketing Mix Modeling)

**Pain Fit:** Doanh nghiệp lớn, ngân sách marketing cao, cần đo lường hiệu quả phân bổ ngân sách giữa các kênh (online/offline), khó biện minh ROI marketing với Ban lãnh đạo/Tài chính.

**DM thường gặp:**
- CMO / Marketing Director — cần chứng minh hiệu quả marketing bằng số liệu
- CFO — cần ngôn ngữ tài chính (ROI, incrementality) để duyệt ngân sách

**3 USP:**
1. Đo lường đóng góp thực tế của từng kênh vào doanh thu, kể cả offline — dữ liệu khách quan, không phụ thuộc báo cáo của platform.
2. Nhiều gói: Full (kèm Strategy), Lite, Mini, Analytics Only — phù hợp cả doanh nghiệp mới bắt đầu đo MMM.
3. Giúp CMO "nói chuyện" hiệu quả hơn với CFO/Board bằng ngôn ngữ tài chính.

**ROI Angle:** Dealsize khoảng 30M–800M tùy gói. Mỗi phần trăm tối ưu phân bổ ngân sách trên tổng ngân sách marketing (thường hàng chục tỷ/năm ở doanh nghiệp lớn) có thể tiết kiệm nhiều hơn gấp nhiều lần chi phí MMM.

**DISC mẫu:**
- D: "MMM cho anh/chị con số cụ thể: kênh nào đang mang lại doanh thu thực sự, để tái phân bổ ngân sách ngay trong quý tới."
- I: "Đây là công cụ giúp kể câu chuyện hiệu quả marketing bằng số liệu thuyết phục hơn rất nhiều khi trình bày với Ban lãnh đạo."
- S: "Tụi em có thể bắt đầu với gói Mini hoặc Analytics Only để team làm quen trước, không cần cam kết ngay gói Full."
- C: "Em có thể chia sẻ phương pháp luận MMM và ví dụ cách tính incrementality để anh/chị đánh giá độ tin cậy trước khi triển khai."
