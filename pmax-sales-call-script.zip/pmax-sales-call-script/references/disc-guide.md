# DISC — nhận diện và cách nói chuyện

DISC là công cụ dự đoán ban đầu để chọn giọng điệu phù hợp, **không phải kết luận tuyệt đối về một người**. Luôn quan sát phản ứng thật của khách trong 30 giây đầu để điều chỉnh, và không nói với khách rằng họ "thuộc nhóm DISC nào" — đây là công cụ nội bộ của BD.

| Nhóm | Đặc điểm nhận biết | Nên làm khi gọi | Tránh làm |
|---|---|---|---|
| **D — Dominance** | Nói nhanh, ngắt lời, hỏi thẳng "vậy được gì", ít hỏi thăm xã giao | Vào thẳng kết quả, số liệu, mốc thời gian cụ thể | Vòng vo, kể lể quá trình, hỏi quá nhiều câu xã giao |
| **I — Influence** | Nói nhiều, thích chia sẻ câu chuyện, dễ hào hứng, hỏi ý kiến cá nhân | Kể chuyện, dùng ví dụ sinh động, khen ngợi chân thành | Liệt kê số liệu khô khan ngay từ đầu, cắt ngang cảm xúc |
| **S — Steadiness** | Nói chậm, thận trọng, hay hỏi lại để chắc chắn, ngại thay đổi đột ngột | Trấn an, đi từng bước, cam kết không xáo trộn quy trình hiện tại | Tạo áp lực chốt nhanh, thay đổi kế hoạch bất ngờ |
| **C — Compliance** | Hỏi chi tiết, muốn xem số liệu/case study, ít bộc lộ cảm xúc qua điện thoại | Chuẩn bị sẵn số liệu, benchmark, case study cụ thể | Nói chung chung, dùng tính từ cảm xúc thay vì bằng chứng |

## Phiên dịch phong cách thành câu chữ khi viết script

- **D:** câu ngắn, động từ hành động đứng đầu, luôn có con số hoặc mốc thời gian, kết ở một next-step cụ thể ngay.
- **I:** mở bằng một câu quan sát/khen thật (không sáo rỗng) về công ty hoặc campaign gần đây, dùng ví dụ hình ảnh thay vì thuật ngữ, giữ năng lượng tích cực.
- **S:** liệt kê rõ các bước sẽ diễn ra tiếp theo, dùng từ trấn an ("không cần cam kết ngay", "đi từng bước"), tránh ngôn ngữ tạo áp lực thời gian.
- **C:** dẫn bằng dữ liệu/case study cụ thể trước khi đưa ra khẳng định, tránh tính từ cảm xúc ("tuyệt vời", "cực kỳ hiệu quả") mà thay bằng con số hoặc phương pháp đo lường.

## Khi chưa biết DISC của khách

Mặc định dùng tông pha trộn: mở đầu kiểu I (ấm áp, cá nhân hóa theo bối cảnh khách) nhưng backup bằng bằng chứng kiểu C (số liệu/case study) ở phần Solution Story, để không lệch quá về một cực nào. Luôn ghi chú một dòng ở đầu script rằng DISC đang là giả định, cần điều chỉnh theo phản ứng thật khi gọi.
