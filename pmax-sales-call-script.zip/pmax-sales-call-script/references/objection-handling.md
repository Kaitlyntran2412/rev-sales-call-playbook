# Objection Handling — khung chuẩn PMAX

Playbook gốc của PMAX định nghĩa 6 nhóm từ chối chuẩn. Mỗi objection nên được viết theo đúng 7 phần dưới đây:

1. **Situation** — bối cảnh khách đang ở đâu khi đưa ra từ chối này
2. **Customer Statement** — câu từ chối điển hình của khách
3. **Sale Response** — câu trả lời của BD
4. **Follow-up Question** — câu hỏi mở tiếp theo để giữ cuộc trò chuyện
5. **Coach Notes** — lưu ý huấn luyện cho BD khi dùng objection này
6. **Mistakes** — lỗi thường gặp cần tránh
7. **When to Stop** — dấu hiệu nên dừng lại, không cố thuyết phục thêm

## Đã viết chi tiết: 3 objection phổ biến nhất

### OBJ-A — Không có thời gian

- **Situation:** xảy ra ngay trong 10–15 giây đầu cuộc gọi (Opening), khi khách đang bận hoặc chưa thấy lý do để dành thời gian.
- **Customer Statement:** "Chị đang bận lắm, em để lại thông tin qua email nhé." / "Anh không có thời gian đâu."
- **Sale Response:** "Dạ em hiểu ạ, em chỉ xin đúng 30 giây để chia sẻ lý do em gọi, nếu không phù hợp em xin phép dừng ngay ạ." Nếu vẫn từ chối: "Vậy để không làm phiền anh/chị, em xin phép gọi lại vào [khung giờ cụ thể] được không ạ, hay anh/chị có khung giờ nào thuận tiện hơn?"
- **Follow-up Question:** "Anh/chị thường rảnh hơn vào buổi sáng hay buổi chiều ạ?"
- **Coach Notes:** đây thường là rào cản bề mặt (surface objection), không phải từ chối thật — mục tiêu là giữ cửa mở, không cố bán trong tình huống này.
- **Mistakes:** cố nói nhanh để nhồi hết thông tin trong 30 giây đã hứa — phá vỡ lòng tin ngay câu đầu; hỏi quá nhiều câu trước khi xin phép.
- **When to Stop:** nếu khách từ chối 2 lần liên tiếp việc hẹn lịch lại, dừng cuộc gọi, chuyển sang follow-up qua email/Zalo thay vì tiếp tục cố gọi.

### OBJ01 — Không có Budget

- **Situation:** thường xuất hiện ở bước Solution Recommendation/Value Proposition, sau khi khách đã nghe sơ qua về giải pháp.
- **Customer Statement:** "Bên em hiện chưa có ngân sách cho việc này." / "Ngân sách marketing năm nay đã chốt hết rồi."
- **Sale Response:** "Dạ em hiểu, nhiều anh chị em làm việc cùng cũng ở tình huống tương tự lúc đầu trao đổi. Cho em hỏi thêm, hiện tại ngân sách đã chốt cho cả năm hay chỉ tạm thời chưa ưu tiên ạ? Vì thực ra tụi em cũng có những gói linh hoạt theo từng giai đoạn ngân sách, không nhất thiết phải là khoản đầu tư lớn ngay từ đầu."
- **Follow-up Question:** "Nếu có một giải pháp phù hợp với ngân sách hiện tại, anh/chị có sẵn sàng nghe thử không ạ?" hoặc "Ngân sách dự kiến sẽ được review lại vào thời điểm nào ạ?"
- **Coach Notes:** phân biệt rõ 2 tình huống — (1) thật sự không có ngân sách (cần hẹn follow-up đúng chu kỳ ngân sách, quý sau/năm sau), (2) chưa thấy đủ giá trị để ưu tiên ngân sách (cần quay lại Pain/ROI để làm rõ giá trị trước khi nói tiếp về giá).
- **Mistakes:** giảm giá ngay lập tức để giữ chân khách — làm giảm giá trị cảm nhận; bỏ cuộc ngay khi nghe "không có ngân sách" mà không tìm hiểu nguyên nhân thật.
- **When to Stop:** nếu khách xác nhận ngân sách đã khoá hoàn toàn cho cả năm và không có ngoại lệ, chuyển sang nuôi dưỡng dài hạn (gửi thêm case study/insight định kỳ, không tiếp tục pitch bán ngay), hẹn quay lại đúng chu kỳ ngân sách tiếp theo.

### OBJ06 — Không có nhu cầu (Not Priority)

- **Situation:** xuất hiện sau khi giới thiệu ngắn về PMAX hoặc trong Discovery, khi khách cho rằng hiện tại không cần giải pháp này.
- **Customer Statement:** "Bên anh/chị hiện không có nhu cầu marketing thêm." / "Team em tự làm được rồi."
- **Sale Response:** "Dạ em hiểu, nhiều khách hàng bên em cũng nói vậy lúc đầu, vì team tự làm cũng ổn ở giai đoạn hiện tại. Cho em hỏi thêm, hiện tại kết quả marketing team đang có so với mục tiêu tăng trưởng năm nay đã đạt được như kỳ vọng chưa ạ?"
- **Follow-up Question:** "Nếu có một cách giúp team giảm tải công việc mà vẫn giữ được kết quả, hoặc tăng thêm kết quả với cùng nguồn lực, anh/chị có muốn tham khảo không ạ?"
- **Coach Notes:** "không có nhu cầu" thường là chưa nhận ra pain, chứ không phải thật sự không có vấn đề — quay lại Discovery để khai thác Business Goal/Current Challenge thay vì thuyết phục trực tiếp.
- **Mistakes:** tranh luận để chứng minh khách "sai" khi nói không cần; giới thiệu giải pháp ngay khi chưa xác nhận được pain thật.
- **When to Stop:** nếu sau 2 câu hỏi mở khách vẫn khẳng định chắc chắn không có vấn đề gì cần giải quyết và không có dấu hiệu tò mò, tôn trọng quyết định, xin phép giữ liên lạc định kỳ (nurture bằng nội dung hữu ích), không ép tiếp.

> **Lưu ý:** 3 objection trên được viết dựa trên nguyên tắc chung của framework (Pain → Solution → Value, kết hợp O.C.A.L.L và Level/DISC) để BD có ngay công cụ dùng được, không phải chép nguyên văn từ một tài liệu Objection Handling gốc nào khác — nên xem là bản nháp chất lượng cao, và BD lead có thể tinh chỉnh thêm theo văn phong team.

## Còn thiếu nội dung chi tiết: 3 nhóm objection còn lại

- **OBJ02 — Previous Failure:** khách từng dùng dịch vụ marketing/agency và không hiệu quả.
- **OBJ03 — Need Approval:** khách cần xin duyệt từ cấp trên/ban lãnh đạo trước khi quyết định.
- **OBJ04 — Existing Agency:** khách đang có agency khác đảm nhiệm.
- **OBJ05 — AI Concern:** khách lo ngại về việc dùng AI/công nghệ trong marketing.

> **Lưu ý cho Claude khi dùng skill này:** nội dung chi tiết cho 4 nhóm trên **chưa có trong bộ tài liệu tham khảo được cung cấp cho skill này**. Khi BD hỏi xử lý một trong 4 objection này, hãy: (1) xác nhận objection đó thuộc nhóm nào, (2) viết một Sale Response hợp lý theo đúng cấu trúc 7 phần ở trên, dựa trên nguyên tắc Pain → Solution → Value và dữ liệu USP/ROI trong `products.md`, và (3) nói rõ với BD rằng đây là gợi ý dựa trên khung chung, nên đối chiếu với tài liệu Objection Handling đầy đủ (bản gốc) hoặc leader trước khi dùng làm chuẩn chính thức.

