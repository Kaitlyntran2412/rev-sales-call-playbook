# Checklist chuẩn bị trước khi Call

Tổ chức theo đúng 5 biến số của framework, để chuẩn bị có trọng tâm thay vì research dàn trải.

| Biến số | Việc cần làm trước khi call |
|---|---|
| Product | Liệt kê 1–2 sản phẩm phù hợp nhất dựa trên ngành, quy mô và tín hiệu thị trường (campaign đang chạy, agency hiện tại, hoạt động gần đây). |
| DM | Research chức danh, KPI đang phụ trách, vai trò trong quyết định, buying stage, pain có khả năng gặp. |
| 3 USP | Chọn trước 3 USP sẽ dùng cho cuộc gọi này — không cần học thuộc toàn bộ USP của sản phẩm. |
| ROI | Chuẩn bị sẵn 1–2 con số benchmark ngành hoặc case study liên quan để dùng làm bằng chứng khi cần. |
| DISC | Dự đoán phong cách DISC dựa trên chức danh và cách khách phản hồi email/tin nhắn trước đó (nếu có). |

## Gợi ý DISC theo chức danh thường gặp (heuristic ban đầu, không cố định)

| Nhóm chức danh | Phong cách DISC thường gặp |
|---|---|
| Founder / CEO | D hoặc I — quyết đoán hoặc thích câu chuyện lớn, tầm nhìn |
| CMO / Brand Manager | I hoặc C — quan tâm câu chuyện thương hiệu nhưng vẫn cần bằng chứng |
| CFO / Procurement | C — cần số liệu, logic, ROI rõ ràng |
| COO / Operations Manager | C hoặc S — cần quy trình rõ ràng, ít xáo trộn |
| Admin / Marketing Executive | S — thận trọng, cần được trấn an, ít có quyền quyết định cuối |

Đây chỉ là điểm xuất phát — luôn điều chỉnh theo phản ứng thật của khách trong 30 giây đầu cuộc gọi (xem `disc-guide.md`). Xem thêm `level-mapping.md` để xác định Level (C-level/Director/Manager/Executive) của người đang nói chuyện — Level quyết định độ sâu nội dung và loại bằng chứng nên dùng, độc lập với DISC (DISC quyết định giọng điệu).

## O.C.A.L.L — checklist thao tác ngay trước và trong lúc gọi

Framework này từ Internal Sales Workshop "Building a Call Culture" (23/07/2026), dùng như checklist ngắn gọn ngay trước/trong khi gọi, bổ sung ở lớp thao tác cụ thể cho 5 biến số Product × DM × 3 USP × ROI × DISC ở lớp nội dung.

| Bước | Nội dung |
|---|---|
| **Outcome** | Xác định rõ mục tiêu cuộc gọi trước khi gọi. Không gọi để giới thiệu PMAX — gọi để khách thực hiện một hành động cụ thể: đồng ý meeting, đồng ý một cuộc trao đổi ngắn, kết nối Zalo, hoặc xác nhận thời gian follow-up. |
| **Context** | Research khách trước khi gọi: industry, marketing activities, campaign đang triển khai, đối thủ, touchpoint trước đó. Nguồn: Google Ads Library, Facebook Ads Library. LinkedIn chỉ nên dùng để tham khảo vì thông tin có thể chưa cập nhật. |
| **Approach** | Chuẩn bị lý do gọi, giá trị mang lại, cách xin phép khách dành khoảng 30 giây. Nếu khách đang bận: xin lịch gọi lại, hoặc xin phép kết nối Zalo. |
| **Lead** | Kết thúc cuộc gọi bằng một next step cụ thể. Không để cuộc gọi kết thúc mà không có hành động tiếp theo. |
| **Learn** | Ngay sau cuộc gọi: ghi lại insight, objection, update CRM, và thực hiện follow-up đúng cam kết đã hẹn. |

Liên hệ với framework chính: Outcome + Context ứng với Pre-call Preparation; Approach là nơi áp dụng Level + DISC để mở đầu đúng độ sâu và giọng điệu; Lead là bước Book Meeting; Learn nuôi dữ liệu cho Discovery và Solution Story lần sau.

## Ba tình huống BD hay gặp khó khăn nhất (từ workshop)

- **Cold prospecting** — không bán ngay, mục tiêu là tạo được một bước tiến tiếp theo.
- **Follow-up sau email chưa có phản hồi** — nếu khách sắp triển khai campaign, chủ động gọi thay vì tiếp tục chờ.
- **Follow-up sau proposal** khi khách đang xin phê duyệt nội bộ — tiếp tục follow-up, làm rõ tiêu chí đánh giá, và chuyển cuộc trao đổi từ giá (price) sang giá trị (value).
