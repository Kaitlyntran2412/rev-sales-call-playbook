# Framework: Product × DM × 3 USP × ROI × DISC

## Vì sao cần framework này

PMAX Sales Call Decision Playbook cho BD một khung chuẩn cho toàn bộ hành trình cuộc gọi:

Research → Trigger → Opening → Discovery → Pain → Solution Consulting → Value → Meeting → Objection Handling.

Framework 5 biến số này bổ sung cách cá nhân hóa nội dung ở đúng bước quan trọng nhất — **Solution Recommendation / Solution Story / Value Proposition** — thay vì dùng một kịch bản chung cho mọi khách hàng, mọi sản phẩm.

## Năm biến số

| Biến số | Trả lời câu hỏi | Vai trò trong cuộc gọi |
|---|---|---|
| Product | Nói CÁI GÌ? | Chọn đúng 1 trong 9 nhóm giải pháp PMAX phù hợp với pain của khách. |
| DM (Decision Maker) | Nói VỚI AI? | Xác định chức danh, KPI, buying stage của người đang nghe máy. |
| 3 USP | Nói ĐIỂM GÌ? | Chỉ chốt 3 điểm mạnh nhất của sản phẩm, tránh liệt kê lan man. |
| ROI | Nói BẰNG BẰNG CHỨNG GÌ? | Dịch USP sang ngôn ngữ tài chính/kết quả đo lường được — DM luôn cần lý do để trình cấp trên. |
| DISC | Nói NHƯ THẾ NÀO? | Điều chỉnh nhịp độ, ngôn từ, cấu trúc câu theo phong cách hành vi của DM — nội dung cốt lõi không đổi. |

5 biến số này lồng vào khung Sales Call Journey đã có: khi tới bước Solution Recommendation, BD chọn Product phù hợp với Pain vừa xác nhận, xác định DM đang nói chuyện là ai, chọn 3 USP và bằng chứng ROI tương ứng, rồi truyền tải bằng giọng điệu đúng phong cách DISC của người nghe.

## Sales Call Journey gốc (tóm tắt, để đối chiếu)

| Bước | Mục tiêu |
|---|---|
| 0. Pre-call Preparation | Research company, research DM, xác định call objective |
| 1. Opening | Tạo lý do chính đáng để khách tiếp tục nghe trong 30 giây đầu |
| 2. Discovery | Hiểu Business Goal → Marketing Goal → Current Challenge → Pain |
| 3. Pain Identification | Xác định khách có vấn đề đủ lớn để cần giải pháp hay chưa |
| 4. Solution Recommendation | Chuyển từ Discovery sang Solution Consulting — đây là nơi framework 5 biến số áp dụng |
| 5. Value Proposition | Khẳng định PMAX giúp giải đúng vấn đề kinh doanh, không chỉ bán dịch vụ |
| 6. Book Meeting | Chuyển từ Call sang Strategy Consulting Session |
| 7. Objection Handling | Xử lý Budget, Previous Failure, Need Approval, Existing Agency, AI Concern, Not Priority |

Opening mẫu gốc (giữ nguyên tinh thần khi viết script mới):

- Greeting: "Em chào anh/chị [Tên], em là [Tên] từ PMAX. Em xin phép trao đổi nhanh với anh/chị một chút về hoạt động Marketing bên mình được không ạ?"
- Trigger: "Em có tìm hiểu thấy gần đây bên mình đang [campaign/product/activity]. Bên em có một số góc nhìn liên quan đến việc tối ưu Marketing cho nhóm ngành này nên em muốn trao đổi nhanh xem có phù hợp với định hướng hiện tại của bên mình không ạ."
- Permission: "Em xin phép hỏi nhanh một vài câu để hiểu thêm bài toán hiện tại của bên mình, nếu thấy phù hợp em xin phép chia sẻ thêm hướng tiếp cận của PMAX được không ạ?"

Discovery Framework gốc (câu hỏi gợi ý theo từng lớp):

| Nội dung | Câu hỏi gợi ý |
|---|---|
| Business Goal | "Mục tiêu ưu tiên nhất của team mình hiện nay là gì ạ?" |
| Marketing Goal | "Marketing hiện đang tập trung hỗ trợ mục tiêu nào ạ?" |
| Current Challenge | "Điều gì đang là thách thức lớn nhất của team mình hiện nay ạ?" |
| Marketing Setup | "Team đang triển khai nội bộ hay kết hợp Agency ạ?" |
| Agency | "Agency hiện đang hỗ trợ những phần nào cho bên mình ạ?" |
| Budget | "Bên mình đang dự kiến đầu tư khoảng bao nhiêu ạ?" |
| Timeline | "Bên mình muốn triển khai hoặc cải thiện trong khoảng thời gian nào ạ?" |
| Decision Maker | "Ngoài anh/chị thì còn ai cùng tham gia đánh giá dự án này ạ?" |
