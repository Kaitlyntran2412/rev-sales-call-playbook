# Script mẫu đầy đủ cho một cuộc gọi

4 script dưới đây là ví dụ hoàn chỉnh (không phải fragment DISC ngắn) — mỗi script đi từ Mở đầu đến Chốt next step, minh hoạ cách kết hợp Product × DM × Level × 3 USP × ROI × DISC trong thực tế, ở 4 tình huống gọi khác nhau. Dùng làm mẫu tham khảo văn phong và cấu trúc; khi viết script thật cho một khách cụ thể, thay bối cảnh/tên/con số cho đúng thực tế.

---

## Script 1 — Cold Prospecting (Media × Manager × DISC D)

**Bối cảnh:** Gọi cho Digital Marketing Manager ngành Real Estate. Research thấy creative quảng cáo bị đổi liên tục trong 2 tuần — dấu hiệu CPL có thể đang chưa ổn định. Outcome mong muốn: đặt được 1 buổi trao đổi 15 phút.

**Mở đầu:**
"Dạ chào anh Minh, em là Lan bên PMAX ạ. Em xin phép anh 30 giây được không ạ? Dạ em có theo dõi thấy bên mình đang chạy khá nhiều campaign quảng cáo dự án X gần đây, và em thấy creative được thay đổi liên tục trong 2 tuần qua — em đoán có thể CPL đang chưa ổn định như kỳ vọng. Bên em đang hỗ trợ một vài chủ đầu tư trong ngành tối ưu lại phần này nên em muốn trao đổi nhanh xem có phù hợp với tình hình bên mình không ạ."

**Khám phá:**
- "Hiện tại CPL trung bình bên mình đang dao động khoảng bao nhiêu ạ?"
- "Ngân sách media hiện đang chia cho bao nhiêu kênh ạ?"
- "Đội ngũ đang tự vận hành hay có agency hỗ trợ ạ?"
- "Mục tiêu CPL bên mình đang nhắm tới là bao nhiêu ạ?"

**Xác nhận Pain:** "Vậy nếu em hiểu đúng, vấn đề lớn nhất hiện tại là CPL đang cao hơn target và team đang phải liên tục đổi creative để thử nghiệm, đúng không ạ?"

**Solution Story (D — ngắn gọn, số liệu):** "Dạ đúng rồi ạ. Bên em có 3 điểm có thể giúp bên mình ngay: Một, tụi em có nhiều hình thức chạy linh hoạt — selfserve, booking, transparent cost — nên tối ưu được chi phí theo đúng ngân sách hiện tại. Hai, tụi em có benchmark CPL riêng cho ngành Real Estate nên biết ngay đang lệch ở đâu. Ba, tụi em tích hợp được với Creative và Data để tối ưu toàn phễu chứ không chỉ tối ưu quảng cáo đơn lẻ. Nếu audit nhanh tài khoản hiện tại, tụi em có thể chỉ ra ngay điểm đang lãng phí ngân sách trong vòng vài ngày."

**Chốt next step:** "Anh Minh thấy vậy có ổn không ạ? Nếu được, em xin phép sắp xếp một buổi 15 phút vào thứ Ba hoặc thứ Năm tuần này để tụi em xem qua tài khoản hiện tại và chia sẻ hướng tối ưu cụ thể hơn được không ạ?"

---

## Script 2 — Follow-up sau Email chưa phản hồi (Branding × Director/C-level × DISC I)

**Bối cảnh:** Đã gửi email giới thiệu PMAX kèm case study branding 3 ngày trước, khách đã mở email 2 lần nhưng chưa phản hồi. Trigger: công ty chuẩn bị ra mắt dự án mới.

**Mở đầu:** "Dạ chào chị Hương, em là Mai bên PMAX ạ, không biết chị có nhớ email em gửi hôm thứ Hai về case study branding tụi em làm cho ngành tương tự không ạ? Em thấy bên mình sắp ra mắt dự án mới nên em gọi luôn để trao đổi nhanh, mong chị dành cho em ít phút được không ạ?"

**Khám phá:**
- "Dự án sắp ra mắt bên mình đang định hướng câu chuyện thương hiệu như thế nào ạ?"
- "Phần communication cho đợt ra mắt này team mình tự làm hay đang tìm thêm đối tác ạ?"
- "Ngoài truyền thông ra mắt, năm nay bên mình có ưu tiên nào khác về xây dựng thương hiệu không ạ?"

**Xác nhận Pain:** "Dạ vậy nghĩa là bên mình đang cần một câu chuyện thương hiệu đủ mạnh và nhất quán trên nhiều kênh cho đợt ra mắt này, và hiện vẫn đang cân nhắc nguồn lực để làm đúng không ạ?"

**Solution Story (I — kể chuyện, ví dụ sinh động):** "Dạ, thật ra đây đúng là giai đoạn tụi em thích làm việc nhất luôn chị, vì lúc ra mắt là lúc câu chuyện thương hiệu có sức ảnh hưởng lớn nhất. Bên em có gói IMC trọn gói — từ Strategy, Creative, Media, đến KOL và PR — nên toàn bộ chiến dịch ra mắt sẽ kể chung một câu chuyện, không bị rời rạc giữa các kênh. Case study gần đây tụi em làm cho một dự án tương tự, brand lift tăng đáng kể chỉ trong giai đoạn ra mắt. Và vì gói có nhiều mức từ Lite đến Premium nên linh hoạt theo ngân sách hiện tại của bên mình nữa."

**Chốt next step:** "Em nghĩ nếu mình trao đổi thêm 20–30 phút, em có thể chia sẻ rõ hơn ý tưởng áp dụng cho dự án lần này của chị luôn. Chị xem tuần này ngày nào tiện để mình đặt lịch được không ạ?"

---

## Script 3 — Follow-up sau Proposal đang chờ duyệt nội bộ (MMM × CFO/C-level × DISC C)

**Bối cảnh:** Đã gửi proposal MMM 1 tuần trước cho CMO, CMO đang trình lên CFO duyệt ngân sách. Gọi để hỗ trợ thêm thông tin giúp CFO ra quyết định.

**Mở đầu:** "Dạ chào anh Tuấn, em là Khoa bên PMAX ạ. Tuần trước bên em có gửi proposal MMM để chị Hà (CMO) trình nội bộ, em gọi để hỏi thăm xem quá trình đánh giá đang tới đâu, và xem có thông tin gì em có thể hỗ trợ thêm để anh dễ ra quyết định hơn không ạ."

**Khám phá:**
- "Hiện tại phía anh đang đánh giá theo tiêu chí nào là chính ạ — chi phí, ROI dự kiến, hay rủi ro triển khai ạ?"
- "Ngoài MMM, anh có đang so sánh với phương án nào khác không ạ?"
- "Mốc thời gian dự kiến duyệt là khi nào để em chủ động follow-up đúng lúc ạ?"

**Xác nhận Pain (chuyển từ giá sang giá trị):** "Dạ em hiểu, với CFO thì bài toán quan trọng nhất thường là con số MMM này giúp tối ưu được bao nhiêu trên tổng ngân sách marketing, đúng không ạ?"

**Solution Story (C — dẫn bằng dữ liệu):** "Dạ đúng vậy. MMM giúp đo lường chính xác đóng góp doanh thu của từng kênh kể cả offline, không phụ thuộc vào báo cáo của platform — đây là điểm CFO thường đánh giá cao vì tính khách quan. Bên em cũng có gói Mini hoặc Analytics Only nếu anh muốn team làm quen trước khi cam kết gói Full, giảm rủi ro đầu tư ban đầu. Về mặt con số, chỉ cần tối ưu một vài phần trăm phân bổ ngân sách trên tổng ngân sách marketing hàng năm, mức tiết kiệm thường lớn hơn nhiều lần chi phí triển khai MMM — em có thể gửi thêm tài liệu minh hoạ cách tính để anh tham khảo trước cuộc họp duyệt."

**Chốt next step:** "Anh thấy nếu em gửi thêm 1 trang tóm tắt số liệu để anh trình cùng proposal thì có giúp được không ạ? Và mình hẹn nhau follow-up lại sau buổi duyệt được không ạ, dự kiến khi nào ạ?"

---

## Script 4 — Tiếp cận qua Gatekeeper/Executive (Leadgen × Executive × DISC S)

**Bối cảnh:** Gọi vào công ty ngành Education, người nghe máy là Marketing Executive — không phải người quyết định. Mục tiêu: xin thông tin và đường dẫn lên đúng người phụ trách.

**Mở đầu:** "Dạ chào em, chị là Vy bên PMAX ạ. Chị gọi để trao đổi nhanh về việc tối ưu lead cho các khoá học bên mình, không biết em có phải là người phụ trách mảng này không, hay chị có thể liên hệ với ai để trao đổi thêm được ạ?"

**Khám phá (nhẹ nhàng, không ép):**
- "Hiện tại bên mình có gặp khó khăn gì về số lượng hoặc chất lượng lead không em biết không ạ?"
- "Mảng leadgen bên mình đang do anh/chị nào phụ trách chính ạ?"

**Xác nhận vai trò & trấn an (S — không tạo áp lực):** "Dạ chị hiểu, không cần em quyết định gì đâu ạ, chị chỉ muốn gửi một tài liệu ngắn gọn để em có thể chuyển tiếp cho anh/chị phụ trách xem trước thôi. Nếu thấy phù hợp thì mình sắp xếp một buổi trao đổi sau cũng được ạ."

**Solution Story (rút gọn, dễ chuyển tiếp):** "Bên chị hiện đang giúp một số đơn vị giáo dục tối ưu toàn bộ phễu từ targeting đến landing page để tăng lead chất lượng, có cả phần phân tích lead trước khi scale ngân sách nên khá an toàn để thử. Chị sẽ gửi 1 trang tóm tắt ngắn để em tiện chuyển tiếp nhé."

**Chốt next step:** "Em cho chị xin email để gửi tài liệu, và nếu tiện, em giúp chị xin thông tin liên hệ của anh/chị phụ trách để chị follow-up trực tiếp được không ạ? Chị cảm ơn em nhiều."

---

## Cách dùng 4 script này khi viết script mới

Khi người dùng yêu cầu một script cho tình huống khác (product/DM/level/DISC khác), dùng 4 script trên làm mẫu về **độ dài, nhịp câu, và cách chuyển giữa các bước** (Mở đầu → Khám phá → Xác nhận Pain → Solution Story → Chốt next step), nhưng thay nội dung theo đúng dữ liệu trong `products.md`, `level-mapping.md` và `disc-guide.md` cho tình huống cụ thể đó — không copy nguyên văn 4 script này cho sản phẩm hoặc DM khác.
