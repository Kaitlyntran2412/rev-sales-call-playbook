# Level & Vai trò của Decision Maker

DISC cho biết BD nên NÓI NHƯ THẾ NÀO. **Level** cho biết BD nên NÓI SÂU TỚI ĐÂU và ĐÁNH VÀO MỐI QUAN TÂM NÀO — vì một CEO, một Director, một Manager và một Executive trong cùng một công ty quan tâm đến những điều hoàn toàn khác nhau khi nghe về cùng một giải pháp. Khi viết script hoặc tư vấn cách approach, luôn xác định Level của người đang nói chuyện, không chỉ dừng ở câu hỏi "có phải C-level hay không".

## 4 cấp bậc (Level)

| Level | Mối quan tâm chính | Vai trò thường gặp trong quyết định | Cách approach | Đánh vào sự quan tâm (hook) |
|---|---|---|---|---|
| **C-level** (CEO/CMO/CFO/COO) | Tăng trưởng doanh thu, ROI tổng thể, vị thế cạnh tranh, rủi ro thương hiệu/vận hành, hiệu quả đầu tư dài hạn. | Decision Maker cuối cùng cho deal lớn (Big Bet/Enterprise); hoặc Influencer cấp cao phê duyệt ngân sách. | Đi thẳng vào business impact, không sa vào chi tiết vận hành. Agenda ngắn gọn, rõ ràng, tôn trọng thời gian. Dùng ngôn ngữ tài chính: ROI, growth, risk. | Kết quả kinh doanh cụ thể và rủi ro nếu không hành động — benchmark ngành, competitive risk, chi phí cơ hội nếu không tối ưu. |
| **Director / Trưởng phòng** | KPI phòng ban, ngân sách được giao, chọn đúng đối tác để không ảnh hưởng uy tín cá nhân, hiệu quả so với kế hoạch năm. | Decision Maker cho deal tầm trung; người trình phương án lên C-level cho deal lớn (Influencer mạnh nhất). | Cân bằng giữa chiến lược và thực thi — cho họ thấy cả bức tranh lớn lẫn cách triển khai cụ thể. Chuẩn bị sẵn tài liệu để họ dùng trình bày lên cấp trên. | Giúp họ trông tốt trước Ban lãnh đạo — số liệu rõ ràng, dễ báo cáo, giảm rủi ro vận hành, uy tín cá nhân khi chọn đúng đối tác. |
| **Manager** | Chất lượng thực thi chiến dịch, tiến độ, hiệu suất so với target được giao, quản lý ngân sách trong phạm vi cho phép. | Influencer mạnh (đề xuất lên Director); đôi khi là Decision Maker cho ngân sách nhỏ/vừa (SME, Small Bet). | Thể hiện quy trình làm việc rõ ràng, cam kết SLA, dễ phối hợp hàng ngày. Luôn giữ Manager trong vòng lặp thông tin ngay cả khi làm việc song song với Director. | Giúp họ đạt KPI cá nhân, giảm khối lượng công việc thủ công, có sẵn báo cáo để trình lên cấp trên dễ dàng. |
| **Executive / Specialist** | Công việc vận hành hàng ngày, dễ sử dụng dịch vụ, được hỗ trợ nhanh, không tạo thêm việc cho họ. | User (người trực tiếp dùng dịch vụ) hoặc Gatekeeper (điểm chạm đầu tiên, có thể chặn hoặc mở đường tiếp cận cấp trên). | Thân thiện, tôn trọng, không đánh giá thấp vai trò dù họ không phải người quyết định cuối. Cung cấp tài liệu ngắn gọn, dễ chuyển tiếp lên cấp trên. | Sự hỗ trợ tận tình, đơn giản hoá công việc, cảm giác được tôn trọng — họ thường là người gác cổng quan trọng nhất. |

## Vai trò trong quyết định (Decision Maker Mapping)

Ngoài Level, mỗi người liên hệ còn giữ một vai trò trong quy trình quyết định:

- **Decision Maker** — người ra quyết định cuối cùng.
- **Influencer** — người có ảnh hưởng đến quyết định, thường trình bày/đề xuất lên Decision Maker.
- **User** — người trực tiếp sử dụng dịch vụ hàng ngày.
- **Gatekeeper** — người kiểm soát hoặc hỗ trợ quy trình tiếp cận, thường là điểm chạm đầu tiên.

Thứ tự thuyết phục thường đi từ Gatekeeper/User (thường là Executive) → Influencer (thường là Manager/Director) → Decision Maker (thường là Director/C-level tuỳ quy mô deal).

## Gợi ý Level thường quyết định theo quy mô deal (heuristic)

| Quy mô deal | Level thường là Decision Maker | Level thường là Influencer/Gatekeeper |
|---|---|---|
| Small Bet (SME, ngân sách nhỏ) | Manager, đôi khi Director | Executive |
| Medium Bet | Director | Manager, Executive |
| Big Bet / Enterprise | C-level | Director, Manager |

Đây là điểm xuất phát để BD ưu tiên đúng người ngay từ đầu — không phải quy tắc tuyệt đối, vẫn cần xác nhận qua Discovery ai thực sự là Decision Maker trong từng trường hợp cụ thể.

## Cách dùng khi viết script

Khi người dùng cho biết chức danh của khách (hoặc mô tả vai trò của họ, ví dụ "chị này là trưởng phòng marketing" hoặc "bạn này chỉ làm operation, chưa quyết được"), map ngay sang 1 trong 4 Level ở trên và điều chỉnh:

1. **Độ sâu nội dung** — C-level/Director cần business impact tổng thể; Manager/Executive cần chi tiết vận hành, quy trình, SLA.
2. **Bằng chứng dùng để thuyết phục (kết hợp với ROI Angle trong `products.md`)** — C-level cần con số tài chính lớn (tăng trưởng, tiết kiệm ngân sách); Manager/Executive cần bằng chứng vận hành (tiến độ, SLA, giảm việc thủ công).
3. **Next-step phù hợp** — với Executive/Gatekeeper, next-step thường là "xin giới thiệu lên cấp trên" hoặc "gửi tài liệu ngắn gọn để họ chuyển tiếp", không nhất thiết là Book Meeting ngay.

Nếu Level chưa rõ, hỏi một câu ngắn hoặc suy luận từ chức danh, đừng bỏ qua bước này — nó thay đổi toàn bộ cách viết Solution Story.
