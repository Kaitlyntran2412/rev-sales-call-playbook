---
name: pmax-sales-call-script
description: Use this skill whenever the user (a PMAX BD) asks to write, draft, or generate a sales call script, cold call script, kịch bản gọi điện, or talk track for a customer call, for any of PMAX's 9 product lines (Influencer, Creative, Strategy, ScanMax, Audit Vista, Media, Leadgen, Branding, MMM). Also use for requests to prep for a call, pick the right product/USP for a customer situation, adapt tone to a customer's personality/DISC style, figure out how to approach a contact based on their organizational level (C-level, Director, Manager, Executive/Specialist) or decision role (Decision Maker, Influencer, User, Gatekeeper), see full end-to-end example call scripts, or handle a customer objection (no time, no budget, no need, previous failure, need approval, existing agency, AI concern). Trigger phrases include "viết script call", "kịch bản gọi khách", "sales call script", "chuẩn bị trước khi gọi khách", "khách này nên nói USP nào", "khách này ở level nào / nên approach thế nào", "manager hay director thì nói sao", "cho ví dụ script đầy đủ", "khách từ chối vì không có thời gian/budget/nhu cầu", "script cho [product]". Do not use for writing marketing copy, ebooks, or unrelated content — this skill is specifically for live sales-call scripts and call prep.
---

# PMAX Sales Call Script Generator

This skill encodes PMAX's Product × DM × 3 USP × ROI × DISC framework so any BD can get a ready-to-use call script without needing separate training. Read the reference files below before writing anything — they contain the actual product data, DM personas, USPs, ROI angles, and DISC phrasing. Never invent numbers, dealsize, or USPs that aren't in these files.

## Reference files (read what you need, not necessarily all of them)

- `references/framework.md` — the 5-variable logic (Product × DM × 3 USP × ROI × DISC) and how it nests inside PMAX's Sales Call Journey (Opening → Discovery → Pain → Solution → Book Meeting → Objection Handling).
- `references/products.md` — for each of the 9 products: Pain Fit, typical DM personas + their KPI, 3 USP, ROI Angle, and one sample DISC line per style (D/I/S/C). This is the core data source for any script.
- `references/disc-guide.md` — how to recognize each DISC style from how the customer talks, and the phrasing rules to follow for each (sentence length, what to lead with, what to avoid). DISC governs HOW to say it.
- `references/level-mapping.md` — the 4 organizational levels (C-level, Director, Manager, Executive/Specialist), each with its own concerns, typical decision role (Decision Maker/Influencer/User/Gatekeeper), how to approach them, and what to hook their attention with. Level governs HOW DEEP to go and WHICH CONCERN to hit — independent of DISC.
- `references/prep-checklist.md` — pre-call research checklist organized by the 5 variables, a chức danh → DISC heuristic table, and the O.C.A.L.L in-call checklist (Outcome, Context, Approach, Lead, Learn).
- `references/full-call-scripts.md` — 4 complete, end-to-end sample call scripts (not short DISC fragments) covering different situations: Cold Prospecting, Follow-up sau Email, Follow-up sau Proposal, and tiếp cận qua Gatekeeper/Executive. Use these as style/structure references when a full script is requested.
- `references/objection-handling.md` — the 6 standard objection categories PMAX handles. 3 of them (No Time, No Budget, Not Priority/No Need) have full written responses; the other 3 are flagged as needing confirmation from the original Playbook.

## When to write a full script

1. **Gather the inputs.** You need: (a) Product — must match one of the 9 in `products.md`; (b) DM — job title, and ideally their KPI/pain; (c) Level — map the job title to one of the 4 levels in `level-mapping.md` (C-level, Director, Manager, Executive/Specialist), and note their likely decision role (Decision Maker/Influencer/User/Gatekeeper); (d) DISC style — ask the user, or infer it from how they describe the contact (e.g. "ông này nói chuyện rất nhanh, hỏi thẳng luôn" → likely D). If DISC is genuinely unknown, default to a blended tone (lead with I-style warmth, back it with C-style evidence) and say so in one line at the top of your output — don't block on it.
   If Product, DM, or Level is ambiguous in a way that would change the whole script, ask **one** clarifying question. Otherwise, make a reasonable assumption, state it in one line, and write the script. Level and DISC answer different questions — Level decides how deep to go and which concern to hit (`level-mapping.md`); DISC decides tone and pacing (`disc-guide.md`). Always resolve both, not just DISC.

2. **Pull the data.** Open `references/products.md` and find the matching product section. Use its Pain Fit, DM table, 3 USP, and ROI Angle verbatim — don't paraphrase the numbers. If the user's actual customer/DM doesn't match any listed persona, adapt the KPI/pain reasoning but keep the USP and ROI Angle as given.

3. **Write the script** in natural, professional spoken Vietnamese, structured in labeled sections so a BD can scan it live on a call:

   - **Mở đầu (Opening):** a Trigger line referencing something specific about the customer (use whatever the user told you about the company/context; if nothing was given, write a placeholder like "[nhắc campaign/hoạt động gần đây của khách]" and flag it needs filling in) + a Permission ask.
   - **Khám phá (Discovery):** 3–5 open questions moving from Business Goal → Marketing Goal → Current Challenge → Pain, relevant to the chosen product.
   - **Xác nhận Pain:** one line reflecting the pain back in the customer's likely words.
   - **Câu chuyện giải pháp (Solution Story):** weave in exactly the 3 USP from `products.md`, using the ROI Angle as the concrete evidence, phrased in the tone `disc-guide.md` prescribes for the chosen DISC style, and pitched at the depth and hook `level-mapping.md` prescribes for the chosen Level (e.g. C-level gets business-impact framing; Manager/Executive gets operational/process framing for the same USP). Never use more than 3 USP.
   - **Chốt bước tiếp theo (Book Meeting):** one specific, concrete next-step ask (not vague "mình trao đổi thêm nhé"). If the contact's Level/role is Executive or Gatekeeper, the next-step is often "xin giới thiệu lên cấp trên" or "gửi tài liệu ngắn gọn để họ chuyển tiếp" rather than booking a meeting directly — check `level-mapping.md` for the decision-role logic.
   - **Xử lý từ chối (optional):** only include if the user asks, or mentions a specific objection — pull the matching structure from `objection-handling.md`.

4. **Keep it usable, not literary.** Short sentences. This is a live-call cheat sheet the BD glances at while talking, not a script to be read verbatim word-for-word — write it so it still sounds natural if paraphrased on the fly.

## When the user asks for something narrower

- **"Khách này nên dùng USP nào?"** → just pull the 3 USP + ROI Angle from `products.md` for that product, no need for a full script.
- **"Chuẩn bị trước khi gọi [khách]"** → use `prep-checklist.md`, filling in what you can from context and flagging what the BD still needs to research.
- **"Khách này nói chuyện kiểu gì / thuộc DISC nào?"** → use `disc-guide.md` to help the BD read the signals, plus the chức danh → DISC heuristic table in `prep-checklist.md`. Always caveat that DISC here is a starting guess, not a diagnosis.
- **"Khách này ở level nào / nên approach thế nào?"** → use `level-mapping.md` to map the job title to C-level/Director/Manager/Executive, state their likely decision role, concern, and hook — this doesn't need DISC to answer.
- **"Chuẩn bị mục tiêu/next step cho cuộc gọi sắp tới"** → use the O.C.A.L.L checklist in `prep-checklist.md`.
- **"Cho ví dụ 1 script gọi đầy đủ"** → pull the closest matching example from `full-call-scripts.md` and adapt it, or write a new full script following the same structure if none match closely.
- **"Khách phản đối vì [lý do]"** → use `objection-handling.md`. For "không có thời gian", "không có budget", "không có nhu cầu" there are full ready-to-use responses; for other objections, follow the guardrail note in that file.

## Guardrails

- Never invent dealsize, ROI figures, or named client examples beyond what's in these reference files or what the user provides.
- Never output more than 3 USP per script, even if the user asks for more — redirect extra points to Discovery questions instead.
- For **ScanMax** specifically, always include the caveat noted in `products.md`: product details are a placeholder and unconfirmed with the Product team — flag this clearly to the BD rather than presenting it as verified.
- If the user gives you information that contradicts a reference file (e.g. a different dealsize they were told directly by Product team), trust the user's live information over the static reference file, but note the discrepancy.
