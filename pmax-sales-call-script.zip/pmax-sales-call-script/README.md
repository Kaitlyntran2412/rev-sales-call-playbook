# Cách cài Skill "PMAX Sales Call Script" vào Claude

Skill này giúp Claude tự viết script gọi khách theo đúng framework Product × DM × 3 USP × ROI × DISC của PMAX — không cần ai training lại, chỉ cần cài 1 lần rồi hỏi Claude bình thường.

## Cách 1 — Dùng trên claude.ai (đơn giản nhất, không cần cài đặt)

1. Nén cả thư mục `pmax-sales-call-script` này thành 1 file `.zip` (nếu bạn nhận file zip sẵn thì bỏ qua bước này).
2. Vào claude.ai → mở một cuộc trò chuyện → vào **Settings (⚙️) → Capabilities/Skills** (hoặc phần "Skills" trong menu).
3. Bấm **Upload skill** (hoặc "Add skill") và chọn file `.zip` vừa nén.
4. Xong. Từ giờ, mỗi khi bạn nhắn kiểu: *"viết script call cho khách ngành Beauty, sản phẩm Influencer, khách nói chuyện nhanh và thẳng"* — Claude sẽ tự áp dụng skill này.

## Cách 2 — Dùng với Claude Code / Claude Desktop (cho máy cá nhân)

1. Copy cả thư mục `pmax-sales-call-script` (giữ nguyên cấu trúc, gồm `SKILL.md` và thư mục `references/`) vào thư mục skill cá nhân của bạn, thường là:
   - `~/.claude/skills/` (macOS/Linux), hoặc
   - thư mục skill do Claude Code/Desktop hiển thị trong phần cài đặt Skills.
2. Khởi động lại Claude Code/Desktop.
3. Dùng như bình thường — không cần gõ lệnh gì đặc biệt, chỉ cần hỏi Claude viết script call.

## Cách dùng sau khi cài xong

Chỉ cần nhắn cho Claude những câu tự nhiên như:

- "Viết script call cho khách ngành Real Estate, sản phẩm Media, chức danh Marketing Manager, khách nói chuyện chậm và hay hỏi lại nhiều lần."
- "Khách này thuộc DISC nào, nói chuyện toàn hỏi số liệu và case study?"
- "Chuẩn bị trước khi gọi 1 khách FMCG đang cân nhắc Influencer."
- "Khách từ chối vì đang có agency khác, xử lý sao?"

Không cần nhắc tên skill hay giải thích framework — Claude sẽ tự nhận diện và áp dụng đúng dữ liệu trong các file `references/`.

## Cập nhật dữ liệu

Nếu USP, dealsize, hoặc DM persona của sản phẩm nào thay đổi, chỉ cần sửa trực tiếp trong `references/products.md` (mở bằng bất kỳ trình soạn thảo text nào) rồi tải/cài lại — không cần sửa `SKILL.md`.
